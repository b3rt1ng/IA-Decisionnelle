21904654 Antoine Collenot
22107526 Kenzo Lecoindre


Mode d'emploi:
	$ant compile #compilation simple du projet
	$ant test #compilation et execution des tests
	$ant doc #génère la javadoc complète du projet
